﻿# Computing Infrastructures Project

Group name: [oliwia.wojcicka_karolina.kawulska_daria.bartkowiak]
Group number: 11
