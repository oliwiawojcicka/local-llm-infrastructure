﻿import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { z } from "zod";

const server = new McpServer({
  name: "time-server",
  version: "1.0.0",
});

server.tool(
  "get_current_time",
  "Returns the current date and time",
  {},
  async () => {
    const now = new Date();
    return {
      content: [
        {
          type: "text",
          text: `Current time: ${now.toISOString()} (local: ${now.toLocaleString()})`,
        },
      ],
    };
  }
);

const transport = new StdioServerTransport();
await server.connect(transport);
