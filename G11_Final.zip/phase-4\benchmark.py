﻿import requests
import time

LOCAL_URL = "http://localhost:11434/v1/chat/completions"
CLOUD_URL = "http://ec2-54-93-101-2.eu-central-1.compute.amazonaws.com:11434/v1/chat/completions"

PROMPT = "What is a CPU? Answer in one sentence."

def measure(url, model, label):
    payload = {
        "model": model,
        "messages": [{"role": "user", "content": PROMPT}],
        "stream": False
    }
    start = time.time()
    response = requests.post(url, json=payload)
    elapsed = time.time() - start
    data = response.json()
    answer = data["choices"][0]["message"]["content"]
    tokens = data["usage"]["completion_tokens"]
    tps = tokens / elapsed
    print(f"\n=== {label} ===")
    print(f"Time: {elapsed:.2f}s")
    print(f"Tokens: {tokens}")
    print(f"Tokens/s: {tps:.2f}")
    print(f"Answer: {answer[:100]}...")

print("Running benchmark...")
measure(LOCAL_URL, "llama3.2:1b", "LOCAL (llama3.2:1b)")
measure(CLOUD_URL, "smollm:135m", "CLOUD EC2 (smollm:135m)")
