﻿import requests

# --- Configuration: change this to use a different model ---
MODEL = "llama3.2:1b"
OLLAMA_URL = "http://localhost:11434/v1/chat/completions"

def ask_ollama(prompt):
    payload = {
        "model": MODEL,
        "messages": [
            {"role": "user", "content": prompt}
        ],
        "stream": False
    }
    response = requests.post(OLLAMA_URL, json=payload)
    response.raise_for_status()
    data = response.json()
    return data["choices"][0]["message"]["content"]

if __name__ == "__main__":
    print(f"Talking to Ollama model: {MODEL}")
    user_prompt = input("Enter your prompt: ")
    answer = ask_ollama(user_prompt)
    print("\nModel answer:\n")
    print(answer)
